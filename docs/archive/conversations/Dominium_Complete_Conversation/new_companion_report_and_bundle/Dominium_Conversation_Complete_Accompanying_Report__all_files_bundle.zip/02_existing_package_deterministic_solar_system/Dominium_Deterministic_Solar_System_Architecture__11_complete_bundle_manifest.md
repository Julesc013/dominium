# Complete Bundle Manifest — Dominium Deterministic Solar-System Architecture

## Package purpose

This manifest describes the final single ZIP bundle created for the Dominium / Domino engine conversation preservation pass.

The bundle includes:

1. the current deterministic-solar-system preservation package files;
2. the previous handoff ZIP for that package;
3. this new accompanying detailed human-readable summary/report;
4. an older related workspace package labelled `Dominium_Robotic_Seed_Civilisation_Architecture` that was present in `/mnt/data` and may be useful for cross-checking;
5. the uploaded source prompt `Pasted text.txt` that defined the preservation requirements;
6. this complete bundle manifest;
7. a SHA-256 checksum list.

## Source and caveat notes

- The primary source scope remains **this chat only** unless a file explicitly says otherwise.
- The current deterministic package is the primary export set.
- The older related workspace package is included for completeness but should not override the current package without manual review.
- External technical claims from earlier assistant responses, especially about Unreal or current data sources, remain **UNCERTAIN / UNVERIFIED** unless separately checked.
- Assistant recommendations should not be promoted to final project decisions unless the user has accepted them.

## Bundle file inventory

| ZIP path | Size bytes | SHA-256 |
|---|---:|---|
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__00_manifest.md` | 2389 | `d8e9ad908bbef8e55e6346bde1dcda1edba52db7671e7604856105b9204e2905` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__01_human_readable_report.md` | 57540 | `320d5e21af78e1398f3784a6e1ecc612c047bfb15e6f2c65477ca87f27186c41` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__02_context_transfer_packet.md` | 4303 | `a07ff9d193d55bc216fa97770b6512922bc0def272e9d700128ce461b26b4078` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__04_registers.md` | 40599 | `3c7af3db6949e29ef45f402f8a85b9d6cbbeffccac4fd63f4dda911ffcc5094a` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__05_aggregator_packet.md` | 27431 | `9674464e0379b64f13eb3d9d404b56a58311661dda0cd9d1f05376ba9932e043` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__06_reader_brief.md` | 3264 | `56d50d85c678d79cae032dda8ad31f794d2aaaa4f967190dc20268b93fc0a5d1` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__07_verification_and_audit.md` | 4723 | `6a7e79ed0adad4851c6cf8d7b9909c1bc6416482aeace50b9a62cd7c35e0165f` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__08_future_chat_bootstrap_prompt.md` | 978 | `984d223840f548c1ed1bb07fe6f59c23ecc570db350091d5345824af1009a8c5` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__09_in_chat_reader.md` | 2199 | `6cd8b657a8b1b9cf9140517e61c2d772b64d59cfe2457c1a558192faad03d366` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__10_accompanying_detailed_summary_and_report.md` | 27925 | `77e4460dd24c17b4139249b0f22468aafc34e9e371ac0132dd9b602ac3bd7b79` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__10_accompanying_full_conversation_report.md` | 32823 | `9aba7fe219d1721223d7682d98dee5e36a777af4927f85300dc1e1812dc59520` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__10_accompanying_human_readable_conversation_report.md` | 20191 | `9c3b31be9005922ef28971375c7ba7c62ce8fc3291d22a1af08ec6e9ccb2da23` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__10_accompanying_human_readable_detailed_summary_report.md` | 29184 | `9e10ec545a94c73aba0eb78ed3215146f460f87f1c74c58c8984fc98c2cf413c` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__12_bundle_verification.md` | 4094 | `30d4738ef8e979bf17cc6a90cfa20cfce9a754326a742d8fd1904d19e18df0c1` |
| `current_deterministic_package/Dominium_Deterministic_Solar_System_Architecture__03_spec_sheet.yaml` | 58575 | `0dcbbc5509d713428dbc0ddd09fe79eedca35e9887b87c20955defb55035e605` |
| `current_deterministic_package/previous_handoff_zip/Dominium_Deterministic_Solar_System_Architecture__handoff_package.zip` | 63147 | `469bfb68b19198d9a1eb3e2e37b985516079cb4b82f960a3842928acbdcf3687` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__00_manifest.md` | 2627 | `320c1fb070acf1ed313d93c571712ba1d2e973e93f2820ffd0ffb2b2a77935bf` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__01_human_readable_report.md` | 33167 | `0b1e56f0d8e572465e285b65cdf0e8a40bea76ffec70a0ff0e901258631c1663` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__02_context_transfer_packet.md` | 5362 | `2212c0a5be7f1ecf672e4cab1a8cd72465379ca168350e6a06a0ccbbb9e19663` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__04_registers.md` | 37669 | `d02a062de85e840f600fae79af2ad3cb99f5c62ddcfb8eea7e2a086f80e3d8b9` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__05_aggregator_packet.md` | 25376 | `056eb47ecc86358dae13b0a1581f167c4defa281071cb88fe45db280a5856604` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__06_reader_brief.md` | 3058 | `95b5d819810c1aaac6171653dff39856d0730566b4515f3eb85a75eeb39d6513` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__07_verification_and_audit.md` | 5158 | `046540e67e94aea1436177d481117b7ea2df5b967cca31c5c0b3af2d4490a7db` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__08_future_chat_bootstrap_prompt.md` | 980 | `4a95d64912ca6a74b63f66059945e50db09ae3c733d423a1cec54ecce60bd3d6` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__09_in_chat_reader.md` | 2406 | `f52c2ca140b41e32d8c1497117ad4078ea18ec1a756fd18ea3c0cb7f184d434f` |
| `older_related_workspace_package/Dominium_Robotic_Seed_Civilisation_Architecture__03_spec_sheet.yaml` | 53240 | `3b0368853afb7ef7af9bcba5c763ee3ca7c99333d1e74ccfa7b1162522298e5c` |
| `older_related_workspace_package/previous_handoff_zip/Dominium_Robotic_Seed_Civilisation_Architecture__handoff_package.zip` | 54889 | `972af06794dd47134da18a0c99f8235ff3e8df6e333d67d4d3461754b5c23a55` |
| `source_prompt/Pasted text.txt` | 31225 | `6686114753accfa0ddd2aa1b3ef159bc685c53892dc58ac61e7574b2ae3636db` |

## Final package status

- Files created in this pass: `Dominium_Deterministic_Solar_System_Architecture__10_accompanying_detailed_summary_and_report.md`, `Dominium_Deterministic_Solar_System_Architecture__11_complete_bundle_manifest.md`, `Dominium_Deterministic_Solar_System_Architecture__12_complete_bundle_checksums.sha256`, `Dominium_Deterministic_Solar_System_Architecture__complete_conversation_bundle.zip`.
- Single final ZIP created: yes.
- Safe for later aggregation: with caveats.
- Main caveats: preserve epistemic labels, manually review older related package before merging, verify stale external claims.
