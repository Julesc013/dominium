# Decisions, Tasks, and Open Questions Digest — Dominium / Domino Conversation

## A. Strong user-stated design directions

| ID | Direction | Status | Notes |
|---|---|---|---|
| D-USER-01 | Deterministic procedural solar-system/planet game | User-stated | Foundation of the technical vision. |
| D-USER-02 | Science-bounded planet generation | User-stated | Sliders should map to plausible physical parameters. |
| D-USER-03 | Procedural fields plus designer/player overlays | User-stated | Needed for saves, packs, terraforming, construction. |
| D-USER-04 | Robotic mothership premise | User-stated | Explains spawn, HUD, recipes, blueprints, progression. |
| D-USER-05 | Players as robot bodies fabricated by machines | User-stated | Spawn points become physical infrastructure. |
| D-USER-06 | Remote spawn labs as expansion milestones | User-stated | Links exploration to infrastructure. |
| D-USER-07 | Nanobot/blueprint construction | User-stated | Provides convenient cut/fill/build tool. |
| D-USER-08 | Automation over worker NPC labour | Strong user-stated preference | Avoids expensive pathfinding/labour simulation. |
| D-USER-09 | Mothership knowledge but limited resources/throughput | User-stated | Prevents recipes from trivialising industry. |
| D-USER-10 | Machines/factories can collapse into process equations | User-stated | Required for scale. |

## B. Assistant recommendations requiring confirmation before becoming formal decisions

| ID | Recommendation | Why it matters | Confirmation needed? |
|---|---|---|---|
| R-AST-01 | Domino as authoritative deterministic simulation core | Avoids giant scene-graph trap | Yes |
| R-AST-02 | Unreal as renderer/client/tooling, not universe truth | Avoids nondeterministic actor-heavy MMO design | Yes |
| R-AST-03 | Fixed tick + event log + snapshots + hashes | Enables replay/debugging/determinism | Yes |
| R-AST-04 | Hierarchical coordinates | Supports solar-system scale | Yes |
| R-AST-05 | Sparse deltas for terrain/construction | Supports editable planets | Yes |
| R-AST-06 | Server-side fog-of-war filtering | Protects hidden info in MMO | Yes |
| R-AST-07 | Machine graph compiler | Lets player machines scale | Yes |
| R-AST-08 | First vertical slice around remote spawn lab | Keeps project testable | Yes |

## C. Highest-priority tasks

1. Define the first vertical slice.
2. Define deterministic simulation invariants.
3. Define field/layer/delta data model.
4. Define mothership resource and fabrication economy.
5. Define robot chassis and respawn rules.
6. Define nanobot construction pipeline.
7. Define machine graph compiler.
8. Define fog-of-war sensor model.
9. Verify current Unreal/engine assumptions.
10. Merge this package with other Dominium chat reports only after preserving labels and caveats.

## D. Highest-priority open questions

1. Is the official starting scope one designed star system, multiple systems, or galaxy-like procedural generation?
2. How strict should science-bounded world generation be?
3. What is the field-layer data model?
4. What exactly limits the mothership?
5. What are the first robot body types?
6. What can nanobots do at each tier?
7. How do player-made machines compile into safe process graphs?
8. How do cities feel alive without worker NPCs?
9. What does fog of war hide, reveal, remember, and infer?
10. What client compute is safe in public MMO mode?
11. What exactly should Unreal do?
12. What is the formal acceptance test for the first vertical slice?

## E. Items deliberately put off

- precise orbital/planet generator schema;
- real data import pipeline;
- reverse generation solver;
- delta compression and save format;
- concrete terrain representation;
- robot chassis catalogue;
- body death/backup rules;
- exact mothership inventory;
- construction griefing controls;
- MMO sharding and handoff protocol;
- economy balance;
- PvP/governance/permissions;
- city liveliness and presentation design;
- full spec-book integration.
