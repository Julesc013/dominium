# Proposed First Vertical Slice — Mothership to Remote Spawn Lab

## Purpose

The first vertical slice should prove Dominium’s core loop before the project expands into full planets, terraforming, cities, megaprojects, or MMO scale.

## Core loop

A player starts as a robot body fabricated by the mothership, leaves the starting area, surveys terrain, finds resources, prepares a construction site, mines ore, refines material, fabricates components, builds a remote spawn lab, and then uses that lab to fabricate or respawn a body.

## Required systems

1. Deterministic local simulation tick.
2. One generated planet region.
3. One mothership with limited resource and fabrication model.
4. One robot chassis.
5. Basic HUD/sensor overlay.
6. Fog-of-war/known-terrain model.
7. One ore/resource deposit.
8. One power source.
9. Cut/fill terrain operation.
10. Blueprint preview and commit.
11. Nanobot or construction actuator.
12. Mine/extractor.
13. Refinery.
14. Fabricator.
15. Transport/storage container.
16. Remote spawn lab.
17. Save/load and replay hash test.

## Non-goals

- Full planet scale.
- MMO scale.
- Multiple stars/systems.
- Complex NPC ecology.
- Human worker simulation.
- Full weather/climate.
- Complex vehicle design.
- Full machine graph compiler.
- High-fidelity Unreal art pass.

## Success criteria

- The same command log produces the same world hash.
- Terrain edits persist as sparse deltas.
- Construction requires material and energy.
- The player can create a remote spawn point through gameplay.
- Fog of war prevents unexplored terrain/resources from being known.
- Machines can run in a simple input/tick/output form.
- The loop is understandable and playable without worker NPCs.

## Main risks

- The loop may feel like chores without enough immediate payoff.
- Nanobots may be too powerful or too constrained.
- Terrain editing may become technically expensive.
- The mothership may trivialise production.
- The game may feel empty without visible machine life.
- The data model may be overbuilt before the loop is fun.

## Recommended next document

Create a formal milestone spec with:

- exact player journey;
- data structures;
- system boundaries;
- UI flow;
- acceptance tests;
- debugging tools;
- implementation order;
- cut features;
- risks and mitigations.
