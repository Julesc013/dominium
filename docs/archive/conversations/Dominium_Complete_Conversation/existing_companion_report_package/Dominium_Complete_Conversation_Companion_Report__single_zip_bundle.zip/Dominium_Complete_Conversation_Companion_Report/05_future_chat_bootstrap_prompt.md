# Future Chat Bootstrap Prompt — Dominium Complete Conversation Companion Package

I am continuing from a preserved Dominium/Domino design conversation. Treat the following as starting context. Preserve FACT / INFERENCE / UNCERTAIN / PROJECT-CONTEXT labels. Do not assume access to the old chat unless I paste it. Do not re-ask answered questions. Verify stale facts before relying on them. Flag contradictions. Do not treat assistant recommendations as user decisions unless explicitly confirmed. Do not repeat rejected defaults such as worker NPC labour as the core city/factory mechanism.

Core context:

Dominium is being shaped as a deterministic robotic seed-civilisation game built with or around the Domino engine. The user wants science-bounded procedural star systems and planets, field/delta overlays, terrain cut/fill, terraforming, machines, factories, cities, megaprojects, fog of war, sparse sensed-only simulation, single-player/private universes, and possible MMO persistence. The lore premise is a robotic mothership sent by humans to another solar system. It manufactures robot bodies and provides recipes/knowledge, but has finite resources and limited throughput. Players spawn from physical fabrication machines and can build remote spawn labs as expansion milestones. Automation should replace worker NPC labour. Nanobots/blueprints are the diegetic construction interface. Machines/factories should compile into process graphs and collapse when distant. Domino should likely own deterministic world truth; Unreal, if used, should likely be renderer/client/tooling only, but this is an assistant recommendation requiring confirmation.

Current best next action:

Turn the mothership-to-remote-spawn-lab loop into a formal vertical-slice milestone spec with systems, data structures, acceptance tests, risks, and cut lines.

When you respond, include:

1. context loaded;
2. top active priorities;
3. key constraints;
4. open questions;
5. contradictions or uncertainties;
6. recommended next action.
