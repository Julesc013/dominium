# Complete Bundle Manifest — Dominium Deterministic Solar-System Architecture

**Date anchor:** 2026-05-27 Australia/Melbourne  
**Bundle purpose:** Single consolidated ZIP package containing the previous preservation exports, the uploaded preservation prompt, and the new accompanying human-readable conversation report.  
**Source scope:** Current conversation plus files found in `/mnt/data` that are clearly Dominium preservation artifacts.

## What was checked

The working directory `/mnt/data` was checked for existing Dominium preservation files. The package includes both the newer `Dominium_Deterministic_Solar_System_Architecture` set and the older/alternate `Dominium_Robotic_Seed_Civilisation_Architecture` set because both are present and relevant to the same preservation/export workflow.

## Bundle contents

| File | Size bytes | SHA-256 prefix |
|---|---:|---|
| `Dominium_Deterministic_Solar_System_Architecture__00_manifest.md` | 2389 | `d8e9ad908bbef8e5` |
| `Dominium_Deterministic_Solar_System_Architecture__01_human_readable_report.md` | 57540 | `320d5e21af78e139` |
| `Dominium_Deterministic_Solar_System_Architecture__02_context_transfer_packet.md` | 4303 | `a07ff9d193d55bc2` |
| `Dominium_Deterministic_Solar_System_Architecture__03_spec_sheet.yaml` | 58575 | `0dcbbc5509d71342` |
| `Dominium_Deterministic_Solar_System_Architecture__04_registers.md` | 40599 | `3c7af3db6949e29e` |
| `Dominium_Deterministic_Solar_System_Architecture__05_aggregator_packet.md` | 27431 | `9674464e0379b64f` |
| `Dominium_Deterministic_Solar_System_Architecture__06_reader_brief.md` | 3264 | `56d50d85c678d79c` |
| `Dominium_Deterministic_Solar_System_Architecture__07_verification_and_audit.md` | 4723 | `6a7e79ed0adad485` |
| `Dominium_Deterministic_Solar_System_Architecture__08_future_chat_bootstrap_prompt.md` | 978 | `984d223840f548c1` |
| `Dominium_Deterministic_Solar_System_Architecture__09_in_chat_reader.md` | 2199 | `6cd8b657a8b1b9cf` |
| `Dominium_Deterministic_Solar_System_Architecture__10_accompanying_human_readable_conversation_report.md` | 20191 | `9c3b31be9005922e` |
| `Dominium_Deterministic_Solar_System_Architecture__handoff_package.zip` | 63147 | `469bfb68b19198d9` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__00_manifest.md` | 2627 | `320c1fb070acf1ed` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__01_human_readable_report.md` | 33167 | `0b1e56f0d8e57246` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__02_context_transfer_packet.md` | 5362 | `2212c0a5be7f1ecf` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__03_spec_sheet.yaml` | 53240 | `3b0368853afb7ef7` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__04_registers.md` | 37669 | `d02a062de85e840f` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__05_aggregator_packet.md` | 25376 | `056eb47ecc86358d` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__06_reader_brief.md` | 3058 | `95b5d819810c1aaa` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__07_verification_and_audit.md` | 5158 | `046540e67e94aea1` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__08_future_chat_bootstrap_prompt.md` | 980 | `4a95d64912ca6a74` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__09_in_chat_reader.md` | 2406 | `f52c2ca140b41e32` |
| `Dominium_Robotic_Seed_Civilisation_Architecture__handoff_package.zip` | 54889 | `972af06794dd4713` |
| `Pasted text.txt` | 31225 | `6686114753accfa0` |


## Notes

- The newer `Dominium_Deterministic_Solar_System_Architecture__01_human_readable_report.md` remains the main formal preservation report.
- The new `Dominium_Deterministic_Solar_System_Architecture__10_accompanying_human_readable_conversation_report.md` is the plain-English companion report requested after the first export.
- The uploaded `Pasted text.txt` preservation prompt is included as source material.
- The previous handoff ZIP files are included as artifacts, even though their individual contents are also present separately.
- External technical claims and assistant recommendations remain subject to verification and user confirmation.

## Package status

- Files checked: 24
- New companion report created: yes
- New consolidated manifest created: yes
- New consolidated ZIP created: yes
- Safe for later aggregation: with caveats and manual review
